# psf/__init__.py

from .psf import __doc__, __all__, __version__
from .psf import *
