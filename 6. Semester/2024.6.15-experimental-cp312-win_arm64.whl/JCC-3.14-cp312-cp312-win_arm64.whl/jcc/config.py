
INCLUDES=['C:\\Program Files\\Microsoft\\jdk-17.0.11.9-hotspot\\bin\\..\\/include', 'C:\\Program Files\\Microsoft\\jdk-17.0.11.9-hotspot\\bin\\..\\/include/win32']
CFLAGS=['/EHsc', '/D_CRT_SECURE_NO_WARNINGS']
DEBUG_CFLAGS=['/Od', '/DDEBUG']
LFLAGS=['/DLL', '/LIBPATH:C:\\Program Files\\Microsoft\\jdk-17.0.11.9-hotspot\\bin\\..\\/lib', 'Ws2_32.lib', 'jvm.lib']
IMPLIB_LFLAGS=['/IMPLIB:%s']
SHARED=True
VERSION="3.14"
