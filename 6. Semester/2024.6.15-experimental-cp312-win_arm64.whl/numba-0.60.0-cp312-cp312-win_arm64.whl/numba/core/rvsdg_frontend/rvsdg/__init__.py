"""
This subpackage contains RVSDG code that should be considered for upstreaming
to numba_rvsdg
"""