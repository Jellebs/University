# Licensed under a 3-clause BSD style license - see LICENSE.rst

dummy_value = {dummy_value}  # noqa F821 This is a template that will be rendered to valid Python
