from collections import namedtuple

HDF5PluginBuildConfig = namedtuple('HDF5PluginBuildConfig', ('openmp', 'native', 'bmi2', 'sse2', 'ssse3', 'avx2', 'avx512', 'cpp11', 'cpp14', 'ipp', 'filter_file_extension', 'embedded_filters'))
build_config = HDF5PluginBuildConfig(**{'openmp': True, 'native': True, 'bmi2': False, 'sse2': False, 'ssse3': False, 'avx2': False, 'avx512': False, 'cpp11': True, 'cpp14': True, 'ipp': False, 'filter_file_extension': '.dll', 'embedded_filters': ('blosc', 'blosc2', 'bshuf', 'bzip2', 'fcidecomp', 'lz4', 'sz', 'sz3', 'zfp', 'zstd')})
