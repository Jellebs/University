Unit tests for pylibjpeg-libjpeg

Dependencies
------------

Required
........
[pytest](https://docs.pytest.org/)
[pylibjpeg-data](https://github.com/pydicom/pylibjpeg-data)

Optional
........
[pylibjpeg](https://github.com/pydicom/pylibjpeg)
[pydicom](https://github.com/pydicom/pydicom)
