"""Set package shortcuts."""

from ._version import __version__  # noqa: F401
from .utils import decode, decode_pixel_data, get_parameters  # noqa: F401
