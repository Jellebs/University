__version__ = "3.9.2"
"""The PyTables version number."""
