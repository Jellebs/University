# -*- coding: utf-8 -*-
# vidsrc/__init__.py

from .vidsrc import __doc__, __version__, VideoSource
