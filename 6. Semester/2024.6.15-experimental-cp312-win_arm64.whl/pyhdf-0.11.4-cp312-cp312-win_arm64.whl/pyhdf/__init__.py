# $Id: __init__.py,v 1.3 2004-08-02 15:22:59 gosselin Exp $
# $Log : $
