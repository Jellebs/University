"""
Python EDA Package
"""

__version__ = "0.29.0"

