from .zfpy import __doc__, __version__
from .zfpy import *
