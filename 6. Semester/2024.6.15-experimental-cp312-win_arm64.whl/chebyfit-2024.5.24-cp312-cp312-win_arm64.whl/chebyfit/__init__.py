# chebyfit/__init__.py

from .chebyfit import *
from .chebyfit import __all__, __doc__, __version__
