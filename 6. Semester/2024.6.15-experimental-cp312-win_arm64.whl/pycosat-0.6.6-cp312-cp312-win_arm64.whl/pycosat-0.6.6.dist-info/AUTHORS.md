All of the people who have made at least one contribution to pycosat.
Authors are sorted alphabetically.

* Aaron Meurer
* Bradley M. Froehle
* Conda Bot
* Daniel Holth
* Ilan Schnell
* Jannis Leidel
* Ken Odegard
* Mike Sarahan
* Ondřej Čertík
* Ray Donnelly
* Travis E. Oliphant
* William Schwartz
