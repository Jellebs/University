# akima/__init__.py

from .akima import __doc__, __all__, __version__
from .akima import *
