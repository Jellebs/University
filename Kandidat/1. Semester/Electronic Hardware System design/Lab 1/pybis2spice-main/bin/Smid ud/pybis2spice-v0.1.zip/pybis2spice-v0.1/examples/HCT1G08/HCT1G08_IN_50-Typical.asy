Version 4
SymbolType BLOCK
RECTANGLE Normal -32 -24 32 24
WINDOW 0 0 -24 Bottom 2
WINDOW 3 0 24 Top 2
SYMATTR Prefix X
SYMATTR Value HCT1G08_IN_50-Typical
SYMATTR ModelFile D:\OneDrive\Projects\pybis2spice\examples\HCT1G08\HCT1G08_IN_50-Input-Typical.sub
PIN -32 0 LEFT 8
PINATTR PinName IN
PINATTR SpiceOrder 1
