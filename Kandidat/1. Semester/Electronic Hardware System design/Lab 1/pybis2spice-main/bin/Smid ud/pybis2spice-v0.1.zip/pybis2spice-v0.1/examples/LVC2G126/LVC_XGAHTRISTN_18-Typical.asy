Version 4
SymbolType BLOCK
RECTANGLE Normal -32 -24 48 24
WINDOW 0 8 -24 Bottom 2
WINDOW 3 8 24 Top 2
WINDOW 39 8 48 Top 2
SYMATTR Prefix X
SYMATTR Value LVC_XGAHTRISTN_18-Typical
SYMATTR ModelFile D:\OneDrive\Projects\pybis2spice\examples\LVC2G126\LVC_XGAHTRISTN_18-Output-Typical.sub
SYMATTR SpiceLine stimulus=1 freq=10Meg duty=0.5 delay=0
PIN 48 0 RIGHT 8
PINATTR PinName OUT
PINATTR SpiceOrder 1
