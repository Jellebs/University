#ifndef AFSPIL_H
#define AFSPIL_H
//const int pinnumre[4] = {A1, A2, A3, A4};
#include <Arduino.h>
void afspil_Lyd(int frekvenser[4], int laengde);
#endif
