#ifndef DISPLAY_H
#define DISPLAY_H
#include <Arduino.h>
void menu();
void chooseDisplay();
void createDisplay(char mode[], char navn[], float vaerdi);
#endif