#ifndef DATATRANSFERFUNCTIONS_H
#define DATATRANSFERFUNCTIONS_H
#include <Arduino.h>

void wireSetup();
void recieveData(int data[][2], int key); 

#endif